import sys
from antlr4 import *
from TuitLexer import TuitLexer
from TuitListener import TuitListener
from TuitParser import TuitParser

def printTokens():
    token_names = {}
    for name, value in TuitLexer.__dict__.items():
        if isinstance(value, int) and name == name.upper():
            token_names[value] = name

    token_names[-1] = "EOF"

    print(token_names)

def getTuitClassification(node):
    classification = "N/A"

    # A partir de la gramática (Tuit.g4) y la estructura del tuit, se ha instanciado el tuit a una clase pure negative/pure positive.
    if (isinstance(node, TuitParser.Pure_positive_tuitContext)):
        classification = "PURE POSITIVE"
    elif (isinstance(node, TuitParser.Pure_negative_tuitContext)):
        classification = "PURE NEGATIVE"
    elif (isinstance(node, TuitParser.Undetermined_tuitContext)):
        classification = "UNDETERMINED"

    return classification

def analyzeTuit(tuit, ctx):
    # Lo ideal es que siempre tengamos 1 sólo hijo, lo que significará que se ha clasificado a partir del fichero de gramática (Tuit.g4). Si tenemos más, probablemente significará que el tuit contiene algo en su estructura que no estará previsto en el fichero de gramática.
    if (ctx.getChildCount() == 0):
        print("0 hijos, a ver qué hacemos.")
    elif (ctx.getChildCount() == 1):
        # print("1 hijo de tipo: " + str(type(ctx.getChild(0))))
        node = ctx.getChild(0)
        tuit._CLASSIFICATION = getTuitClassification(node)
    elif (ctx.getChildCount() == 2):
        print("2 hijos a ver qué hacemos.")
    else:
        print("Más de 2 hijos, a ver qué hacemos.")

def analyzeElements(tuit, node):
    token_names = {}
    for name, value in TuitLexer.__dict__.items():
        if isinstance(value, int) and name == name.upper():
            token_names[value] = name

    token_names[-1] = "EOF"

    node_type = node.getSymbol().__dict__["type"]

    if (token_names[node_type] == "POSITIVE_EXPRESSIONS"):
        tuit._POSITIVE_VALUES = tuit._POSITIVE_VALUES + 1
    elif (token_names[node_type] == "NEGATIVE_EXPRESSIONS"):
        tuit._NEGATIVE_VALUES = tuit._NEGATIVE_VALUES + 1

    print(node.getText() + " - " + token_names[node_type])

class TuitPrintListener(TuitListener):
    _CLASSIFICATION = "N/A"
    _POSITIVE_VALUES = 0
    _NEGATIVE_VALUES = 0
    _TUIT_TEXT = "N/A"

    # printTokens()
    def enterTuit(self, ctx):
        self._TUIT_TEXT = ctx.getText()
        analyzeTuit(self, ctx)
    def exitTuit(self, ctx):
        pass
    def enterParse(self, ctx):
        pass
    def exitParse(self, ctx):
        pass
    def enterEveryRule(self, ctx):
        pass
    def exitEveryRule(self, ctx):
        pass
    def visitTerminal(self, node):
        # Este método analiza elemento a elemento. 
        # Lo utilizaremos cuando la regla haya sido previamente clasificada como "indeterminada", para valorar palabra a palabra si el tuit es positivo o no.
        if (self._CLASSIFICATION == "UNDETERMINED"):
            print("El tuit '" + self._TUIT_TEXT + "' ha sido clasificado como '" + self._CLASSIFICATION + "', por lo que lo analizamos elemento a elemento.")
            analyzeElements(self, node)
    def visitErrorNode(self, ctx):
        pass

def classifyTuit(tuit):
    # Input from file
    # input = FileStream(sys.argv[1])
    # tuit = "Management Solutions es cojonuda como empresa"
    tuit = tuit.replace("\n", "")
    input = InputStream(tuit)
    lexer = TuitLexer(input)
    stream = CommonTokenStream(lexer)
    parser = TuitParser(stream)

    tree = parser.tuit()

    printer = TuitPrintListener()
    walker = ParseTreeWalker()
    walker.walk(printer, tree)
    print("El tuit '" + tuit + "' se ha clasificado como: " + printer._CLASSIFICATION)
    #print(tree.toStringTree(recog=parser))


if __name__ == '__main__':
    f = open("/Users/andres/Desktop/test_antlr4/Tuit/tuits.txt", "r")
    tuits = f.readlines()
    for tuit in tuits:
        classifyTuit(tuit)